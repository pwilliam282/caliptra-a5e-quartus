create_clock -name clk -period 20.000 [get_ports clk]
set_false_path -from [get_ports {cptra_rst_b cptra_pwrgood}]
